// assets/js/main.js
// Main JavaScript for СВК Авто website

(function() {
  'use strict';

  // Mobile menu toggle
  const menuToggle = document.querySelector('.menu-toggle');
  const menu = document.getElementById('menu');

  if (menuToggle && menu) {
    menuToggle.addEventListener('click', function() {
      const isExpanded = this.getAttribute('aria-expanded') === 'true';
      this.setAttribute('aria-expanded', !isExpanded);
      menu.classList.toggle('is-open');
    });
  }

  // Close menu when clicking outside
  document.addEventListener('click', function(e) {
    if (menu && menu.classList.contains('is-open')) {
      if (!menu.contains(e.target) && !menuToggle.contains(e.target)) {
        menu.classList.remove('is-open');
        menuToggle.setAttribute('aria-expanded', 'false');
      }
    }
  });

  // Smooth scroll for anchor links
  document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function(e) {
      const targetId = this.getAttribute('href');
      if (targetId === '#') return;
      
      const targetElement = document.querySelector(targetId);
      if (targetElement) {
        e.preventDefault();
        targetElement.scrollIntoView({
          behavior: 'smooth',
          block: 'start'
        });
      }
    });
  });

  // Phone mask for callback form
  const phoneInputs = document.querySelectorAll('input[type="tel"]');
  
  phoneInputs.forEach(input => {
    input.addEventListener('input', function(e) {
      let value = this.value.replace(/\D/g, '');
      
      if (value.length > 0) {
        if (value[0] === '7' || value[0] === '8') {
          value = value.substring(1);
        }
        
        let formatted = '+7';
        
        if (value.length > 0) {
          formatted += ' (' + value.substring(0, 3);
        }
        if (value.length >= 3) {
          formatted += ') ' + value.substring(3, 6);
        }
        if (value.length >= 6) {
          formatted += '-' + value.substring(6, 8);
        }
        if (value.length >= 8) {
          formatted += '-' + value.substring(8, 10);
        }
        
        this.value = formatted;
      }
    });
  });

  // Callback form handler
  const callbackForm = document.getElementById('callback-form');
  
  if (callbackForm) {
    callbackForm.addEventListener('submit', async function(e) {
      e.preventDefault();
      
      const formData = new FormData(this);
      const data = Object.fromEntries(formData);
      
      const submitBtn = this.querySelector('button[type="submit"]');
      const originalText = submitBtn.textContent;
      submitBtn.disabled = true;
      submitBtn.textContent = 'Отправка...';
      
      try {
        const response = await fetch('/api/callback', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json'
          },
          body: JSON.stringify(data)
        });
        
        if (response.ok) {
          this.innerHTML = `
            <div class="form-success">
              <h3>Спасибо!</h3>
              <p>Перезвоним вам в течение 30 минут в рабочее время (09:00–20:00).</p>
            </div>
          `;
        } else {
          throw new Error('Failed to submit');
        }
      } catch (error) {
        submitBtn.disabled = false;
        submitBtn.textContent = originalText;
        alert('Произошла ошибка. Пожалуйста, позвоните нам напрямую.');
      }
    });
  }

  // Lazy load images
  if ('IntersectionObserver' in window) {
    const imageObserver = new IntersectionObserver((entries, observer) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          const img = entry.target;
          if (img.dataset.src) {
            img.src = img.dataset.src;
            img.removeAttribute('data-src');
          }
          if (img.dataset.srcset) {
            img.srcset = img.dataset.srcset;
            img.removeAttribute('data-srcset');
          }
          observer.unobserve(img);
        }
      });
    }, {
      rootMargin: '50px 0px'
    });

    document.querySelectorAll('img[data-src]').forEach(img => {
      imageObserver.observe(img);
    });
  }

  // Add loaded class for fade-in animations (CSS handles the rest)
  document.addEventListener('DOMContentLoaded', function() {
    document.body.classList.add('js-loaded');
  });
})();
