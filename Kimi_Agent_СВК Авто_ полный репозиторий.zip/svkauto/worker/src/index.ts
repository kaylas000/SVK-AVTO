// worker/src/index.ts
// Main router for Cloudflare Worker

import { handleChat } from './chat';
import { handlePublisher } from './publisher';
import { handlePlanner } from './planner';
import { handleCallback } from './callback';
import { checkHealth } from './health';

export interface Env {
  DB: D1Database;
  GROQ_API_KEY: string;
  GITHUB_TOKEN: string;
  GITHUB_OWNER: string;
  GITHUB_REPO: string;
  GITHUB_BRANCH: string;
  SITE_BASE_URL: string;
  CF_ACCOUNT_ID: string;
  CHAT_AUTH_TOKEN: string;
  TURNSTILE_SECRET_KEY: string;
  INDEXNOW_KEY: string;
}

// CORS headers
const corsHeaders = {
  'Access-Control-Allow-Origin': 'https://svkautoplus.ru',
  'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type, Authorization',
};

export default {
  async fetch(request: Request, env: Env, ctx: ExecutionContext): Promise<Response> {
    const url = new URL(request.url);
    const path = url.pathname;

    // Handle CORS preflight
    if (request.method === 'OPTIONS') {
      return new Response(null, { headers: corsHeaders });
    }

    try {
      // Router
      switch (path) {
        case '/api/health':
          return await checkHealth(request, env);

        case '/api/consult/chat':
          return await handleChat(request, env);

        case '/api/callback':
          return await handleCallback(request, env);

        case '/api/run-now':
          return await handlePublisher(request, env, true);

        case '/api/plan-now':
          return await handlePlanner(request, env, true);

        default:
          return new Response('Not Found', { 
            status: 404,
            headers: corsHeaders
          });
      }
    } catch (error) {
      console.error('Worker error:', error);
      return new Response(JSON.stringify({ 
        error: 'Internal Server Error',
        message: error instanceof Error ? error.message : 'Unknown error'
      }), {
        status: 500,
        headers: {
          'Content-Type': 'application/json',
          ...corsHeaders
        }
      });
    }
  },

  // Cron trigger handler
  async scheduled(event: ScheduledEvent, env: Env, ctx: ExecutionContext): Promise<void> {
    const now = new Date();
    const dayOfWeek = now.getUTCDay(); // 0 = Sunday, 1 = Monday, etc.
    const hour = now.getUTCHours();
    const minute = now.getUTCMinutes();

    // Planner: Sunday at 05:00 UTC
    if (dayOfWeek === 0 && hour === 5 && minute < 10) {
      console.log('Running planner job');
      await handlePlanner(null as any, env, false);
    }

    // Publisher: Daily at 06:05 UTC (only Mon/Wed/Fri in Moscow time)
    if (hour === 6 && minute >= 5 && minute < 15) {
      // Convert to Moscow time (UTC+3)
      const moscowDay = (dayOfWeek + 3) % 7;
      // Monday=1, Wednesday=3, Friday=5
      if ([1, 3, 5].includes(moscowDay === 0 ? 7 : moscowDay)) {
        console.log('Running publisher job');
        await handlePublisher(null as any, env, false);
      }
    }
  }
};
