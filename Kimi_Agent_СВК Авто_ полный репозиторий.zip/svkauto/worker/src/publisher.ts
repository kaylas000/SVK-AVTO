// worker/src/publisher.ts
// AI Blog Publisher - generates and publishes articles

import { Env } from './index';
import { generateImage } from './ai-image';
import { submitToIndexNow } from './indexnow';

interface CalendarSlot {
  pub_date: string;
  topic_id: string;
  category: string;
  system: string;
  angle: string;
  title_draft: string;
  keywords: string;
  image_prompt: string;
  status: string;
  post_slug?: string;
}

interface GeneratedArticle {
  title: string;
  h1: string;
  description: string;
  slug: string;
  outline: string[];
  faq: Array<{ question: string; answer: string }>;
  tags: string[];
}

// Generate article using Groq
async function generateArticle(slot: CalendarSlot, apiKey: string): Promise<GeneratedArticle> {
  const prompt = `Напиши статью для блога автосервиса на тему: ${slot.category} — ${slot.system} (${slot.angle}).

Требования:
- Практичная, полезная статья для владельцев японских и корейских автомобилей
- Объём: 1500–2000 слов
- Структура: введение, 3–5 разделов с подзаголовками, заключение
- FAQ: минимум 3 вопроса-ответа
- Теги: 5–7 ключевых слов
- Не используй юридические советы, не давай опасных рекомендаций
- Не называй конкурентов
- Не придумывай цены и сроки

Верни СТРОГИЙ JSON:
{
  "title": "заголовок для SEO (до 60 символов)",
  "h1": "заголовок H1",
  "description": "описание для meta (до 155 символов)",
  "slug": "url-slug-na-latince",
  "outline": ["раздел 1", "раздел 2", "раздел 3"],
  "faq": [{"question": "...", "answer": "..."}],
  "tags": ["тег1", "тег2"]
}`;

  const response = await fetch('https://api.groq.com/openai/v1/chat/completions', {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${apiKey}`,
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({
      model: 'llama-3.1-70b-versatile',
      messages: [
        { 
          role: 'system', 
          content: 'Ты — профессиональный автомобильный журналист. Пишешь для блога автосервиса СВК Авто. Отвечай только JSON, без markdown, без комментариев.' 
        },
        { role: 'user', content: prompt }
      ],
      temperature: 0.7,
      max_tokens: 4000
    })
  });

  if (!response.ok) {
    throw new Error(`Groq API error: ${response.status}`);
  }

  const data = await response.json();
  const content = data.choices[0]?.message?.content || '';
  
  // Extract JSON
  const jsonMatch = content.match(/\{[\s\S]*\}/);
  if (!jsonMatch) {
    throw new Error('Failed to extract JSON from response');
  }

  return JSON.parse(jsonMatch[0]);
}

// Generate full article content
async function generateFullContent(article: GeneratedArticle, slot: CalendarSlot, apiKey: string): Promise<string> {
  const prompt = `Напиши полный текст статьи по плану:

Заголовок: ${article.h1}
Тема: ${slot.category} — ${slot.system}
Разделы: ${article.outline.join(', ')}

Требования:
- Каждый раздел: 300–400 слов
- Практические советы, конкретика
- Для владельцев японских и корейских авто (Toyota, Honda, Hyundai, Kia и др.)
- Не давай советов по самостоятельному ремонту узлов безопасности
- Не придумывай цены
- Упомяни, что для точной диагностики лучше обратиться к специалистам

Верни только текст статьи в формате Markdown.`;

  const response = await fetch('https://api.groq.com/openai/v1/chat/completions', {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${apiKey}`,
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({
      model: 'llama-3.1-70b-versatile',
      messages: [
        { role: 'system', content: 'Ты — профессиональный автомобильный журналист.' },
        { role: 'user', content: prompt }
      ],
      temperature: 0.7,
      max_tokens: 4000
    })
  });

  const data = await response.json();
  return data.choices[0]?.message?.content || '';
}

// Commit to GitHub
async function commitToGitHub(
  env: Env,
  slug: string,
  date: string,
  content: string,
  imageData: Uint8Array | null
): Promise<string> {
  const { GITHUB_TOKEN, GITHUB_OWNER, GITHUB_REPO, GITHUB_BRANCH } = env;

  // Create blob for markdown
  const markdownContent = `---
layout: post
title: "${content.match(/title:\s*"([^"]+)"/)?.[1] || slug}"
description: "${content.match(/description:\s*"([^"]+)"/)?.[1] || ''}"
date: ${date}
category: "${content.match(/category:\s*"([^"]+)"/)?.[1] || 'Общее'}"
tags: [${(content.match(/tags:\s*\[([^\]]+)\]/)?.[1] || '').split(',').map(t => `"${t.trim()}"`).join(', ')}]
image: ${imageData ? `/assets/preview/${date.replace(/-/g, '/')}/${slug}.png` : '/assets/default-preview.jpg'}
---

${content}
`;

  // GitHub API base URL
  const baseUrl = `https://api.github.com/repos/${GITHUB_OWNER}/${GITHUB_REPO}`;
  const headers = {
    'Authorization': `Bearer ${GITHUB_TOKEN}`,
    'Accept': 'application/vnd.github+json',
    'X-GitHub-Api-Version': '2022-11-28'
  };

  // Check if file already exists
  const postPath = `_posts/${date}-${slug}.md`;
  const checkResponse = await fetch(`${baseUrl}/contents/${postPath}?ref=${GITHUB_BRANCH}`, {
    headers
  });

  if (checkResponse.status === 200) {
    console.log(`File ${postPath} already exists, skipping`);
    return 'already_exists';
  }

  // Create blob
  const blobResponse = await fetch(`${baseUrl}/git/blobs`, {
    method: 'POST',
    headers,
    body: JSON.stringify({
      content: btoa(unescape(encodeURIComponent(markdownContent))),
      encoding: 'base64'
    })
  });

  const blob = await blobResponse.json();

  // Get current commit SHA
  const refResponse = await fetch(`${baseUrl}/git/refs/heads/${GITHUB_BRANCH}`, { headers });
  const ref = await refResponse.json();
  const currentCommitSha = ref.object.sha;

  // Get current tree
  const commitResponse = await fetch(`${baseUrl}/git/commits/${currentCommitSha}`, { headers });
  const commit = await commitResponse.json();
  const currentTreeSha = commit.tree.sha;

  // Create new tree
  const treeData: any[] = [
    {
      path: postPath,
      mode: '100644',
      type: 'blob',
      sha: blob.sha
    }
  ];

  // Add image if generated
  if (imageData) {
    const imageBlobResponse = await fetch(`${baseUrl}/git/blobs`, {
      method: 'POST',
      headers,
      body: JSON.stringify({
        content: btoa(String.fromCharCode(...imageData)),
        encoding: 'base64'
      })
    });
    const imageBlob = await imageBlobResponse.json();
    
    treeData.push({
      path: `assets/preview/${date.replace(/-/g, '/')}/${slug}.png`,
      mode: '100644',
      type: 'blob',
      sha: imageBlob.sha
    });
  }

  const treeResponse = await fetch(`${baseUrl}/git/trees`, {
    method: 'POST',
    headers,
    body: JSON.stringify({
      base_tree: currentTreeSha,
      tree: treeData
    })
  });

  const tree = await treeResponse.json();

  // Create commit
  const newCommitResponse = await fetch(`${baseUrl}/git/commits`, {
    method: 'POST',
    headers,
    body: JSON.stringify({
      message: `Add blog post: ${slug}`,
      tree: tree.sha,
      parents: [currentCommitSha]
    })
  });

  const newCommit = await newCommitResponse.json();

  // Update ref
  await fetch(`${baseUrl}/git/refs/heads/${GITHUB_BRANCH}`, {
    method: 'PATCH',
    headers,
    body: JSON.stringify({
      sha: newCommit.sha
    })
  });

  return newCommit.sha;
}

export async function handlePublisher(
  request: Request | null, 
  env: Env, 
  isManual: boolean
): Promise<Response> {
  // Auth check for manual trigger
  if (isManual && request) {
    const authHeader = request.headers.get('Authorization');
    if (!authHeader || !authHeader.startsWith('Bearer ') || 
        authHeader.slice(7) !== env.CHAT_AUTH_TOKEN) {
      return new Response('Unauthorized', { status: 401 });
    }
  }

  // Get Moscow date
  const now = new Date();
  const moscowDate = new Date(now.getTime() + (3 * 60 * 60 * 1000)); // UTC+3
  const today = moscowDate.toISOString().split('T')[0];

  // Check if it's a publishing day (Mon, Wed, Fri)
  const dayOfWeek = moscowDate.getDay();
  if (!isManual && ![1, 3, 5].includes(dayOfWeek)) {
    return new Response(JSON.stringify({ 
      message: 'Not a publishing day',
      today,
      dayOfWeek
    }), { headers: { 'Content-Type': 'application/json' } });
  }

  try {
    // Get today's slot
    const slot = await env.DB.prepare(
      'SELECT * FROM calendar_slots WHERE pub_date = ?'
    )
    .bind(today)
    .first<CalendarSlot>();

    if (!slot) {
      return new Response(JSON.stringify({ 
        message: 'No slot for today',
        today
      }), { headers: { 'Content-Type': 'application/json' } });
    }

    if (slot.status === 'published') {
      return new Response(JSON.stringify({ 
        message: 'Already published',
        slot
      }), { headers: { 'Content-Type': 'application/json' } });
    }

    // Check for stuck job
    if (slot.status === 'started' && slot.updated_at) {
      const updated = new Date(slot.updated_at);
      const diffMinutes = (now.getTime() - updated.getTime()) / (1000 * 60);
      if (diffMinutes < 20) {
        return new Response(JSON.stringify({ 
          message: 'Job in progress',
          slot
        }), { headers: { 'Content-Type': 'application/json' } });
      }
      // Reset stuck job
      await env.DB.prepare(
        "UPDATE calendar_slots SET status = 'failed', error = 'Stuck job reset' WHERE pub_date = ?"
      )
      .bind(today)
      .run();
    }

    // Mark as started
    await env.DB.prepare(
      "UPDATE calendar_slots SET status = 'started', updated_at = datetime('now') WHERE pub_date = ?"
    )
    .bind(today)
    .run();

    // Generate article
    const article = await generateArticle(slot, env.GROQ_API_KEY);
    
    // Generate full content
    const fullContent = await generateFullContent(article, slot, env.GROQ_API_KEY);

    // Generate image
    let imageData: Uint8Array | null = null;
    try {
      imageData = await generateImage(
        slot.image_prompt,
        env.CF_ACCOUNT_ID,
        env.GROQ_API_KEY // Using as API token for Workers AI
      );
    } catch (error) {
      console.error('Image generation failed:', error);
    }

    // Commit to GitHub
    const commitSha = await commitToGitHub(env, article.slug, today, fullContent, imageData);

    if (commitSha === 'already_exists') {
      await env.DB.prepare(
        "UPDATE calendar_slots SET status = 'published', post_slug = ?, updated_at = datetime('now') WHERE pub_date = ?"
      )
      .bind(article.slug, today)
      .run();
    } else {
      // Update slot
      await env.DB.prepare(
        "UPDATE calendar_slots SET status = 'published', post_slug = ?, commit_sha = ?, updated_at = datetime('now') WHERE pub_date = ?"
      )
      .bind(article.slug, commitSha, today)
      .run();

      // Submit to IndexNow
      try {
        await submitToIndexNow(
          env.SITE_BASE_URL,
          env.INDEXNOW_KEY,
          `${env.SITE_BASE_URL}/blog/${today.replace(/-/g, '/')}/${article.slug}/`
        );
      } catch (error) {
        console.error('IndexNow submission failed:', error);
      }
    }

    return new Response(JSON.stringify({ 
      success: true,
      message: 'Article published',
      slug: article.slug,
      commitSha: commitSha === 'already_exists' ? null : commitSha
    }), { headers: { 'Content-Type': 'application/json' } });

  } catch (error) {
    console.error('Publisher error:', error);
    
    // Mark as failed
    await env.DB.prepare(
      "UPDATE calendar_slots SET status = 'failed', error = ?, updated_at = datetime('now') WHERE pub_date = ?"
    )
    .bind(error instanceof Error ? error.message : 'Unknown error', today)
    .run();

    return new Response(JSON.stringify({ 
      error: 'Publishing failed',
      message: error instanceof Error ? error.message : 'Unknown error'
    }), { 
      status: 500,
      headers: { 'Content-Type': 'application/json' }
    });
  }
}
