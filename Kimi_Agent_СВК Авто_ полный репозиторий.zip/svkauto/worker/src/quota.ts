// worker/src/quota.ts
// Chat quota management

import { Env } from './index';

interface QuotaRecord {
  visitor_id: string;
  window_start: string;
  used_count: number;
}

export async function checkQuota(db: D1Database, visitorId: string): Promise<number> {
  try {
    const today = new Date().toISOString().split('T')[0];
    
    const result = await db.prepare(
      'SELECT used_count FROM chat_quota WHERE visitor_id = ? AND window_start = ?'
    )
    .bind(visitorId, today)
    .first<QuotaRecord>();

    return result?.used_count || 0;
  } catch (error) {
    console.error('Quota check error:', error);
    return 0;
  }
}

export async function incrementQuota(db: D1Database, visitorId: string): Promise<void> {
  try {
    const today = new Date().toISOString().split('T')[0];
    
    await db.prepare(`
      INSERT INTO chat_quota (visitor_id, window_start, used_count)
      VALUES (?, ?, 1)
      ON CONFLICT(visitor_id, window_start) 
      DO UPDATE SET used_count = used_count + 1
    `)
    .bind(visitorId, today)
    .run();
  } catch (error) {
    console.error('Quota increment error:', error);
  }
}
