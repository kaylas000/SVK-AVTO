// worker/src/health.ts
// Health check endpoint

import { Env } from './index';

export async function checkHealth(request: Request, env: Env): Promise<Response> {
  const checks: Record<string, boolean> = {};

  // Check D1 connection
  try {
    await env.DB.prepare('SELECT 1').first();
    checks.database = true;
  } catch {
    checks.database = false;
  }

  // Check if required secrets are set
  checks.groq_key = !!env.GROQ_API_KEY;
  checks.github_token = !!env.GITHUB_TOKEN;
  checks.turnstile_secret = !!env.TURNSTILE_SECRET_KEY;

  const allHealthy = Object.values(checks).every(v => v);

  return new Response(JSON.stringify({
    status: allHealthy ? 'healthy' : 'degraded',
    timestamp: new Date().toISOString(),
    checks
  }), {
    status: allHealthy ? 200 : 503,
    headers: { 'Content-Type': 'application/json' }
  });
}
