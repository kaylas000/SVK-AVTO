// worker/src/callback.ts
// Callback form handler

import { Env } from './index';

interface CallbackRequest {
  name: string;
  phone: string;
  preferred_time?: string;
}

export async function handleCallback(request: Request, env: Env): Promise<Response> {
  if (request.method !== 'POST') {
    return new Response('Method Not Allowed', { status: 405 });
  }

  // Check Origin
  const origin = request.headers.get('Origin');
  if (origin && !origin.includes('svkautoplus.ru')) {
    return new Response('Forbidden', { status: 403 });
  }

  let body: CallbackRequest;
  try {
    body = await request.json();
  } catch {
    return new Response('Invalid JSON', { status: 400 });
  }

  const { name, phone, preferred_time } = body;

  if (!name || !phone) {
    return new Response(JSON.stringify({ 
      error: 'Missing name or phone' 
    }), { 
      status: 400,
      headers: { 'Content-Type': 'application/json' }
    });
  }

  // Validate phone format (basic)
  const phoneClean = phone.replace(/\D/g, '');
  if (phoneClean.length < 10) {
    return new Response(JSON.stringify({ 
      error: 'Invalid phone number' 
    }), { 
      status: 400,
      headers: { 'Content-Type': 'application/json' }
    });
  }

  // Store in database
  try {
    await env.DB.prepare(`
      INSERT INTO callbacks (name, phone, preferred_time, created_at, status)
      VALUES (?, ?, ?, datetime('now'), 'new')
    `)
    .bind(name, phone, preferred_time || 'day')
    .run();

    // TODO: Send notification (email, Telegram, etc.)
    // For now, just store in DB

    return new Response(JSON.stringify({ 
      success: true,
      message: 'Заявка принята. Перезвоним в течение 30 минут в рабочее время (09:00–20:00).'
    }), {
      headers: { 'Content-Type': 'application/json' }
    });
  } catch (error) {
    console.error('Callback storage error:', error);
    return new Response(JSON.stringify({ 
      error: 'Failed to store callback request' 
    }), { 
      status: 500,
      headers: { 'Content-Type': 'application/json' }
    });
  }
}
