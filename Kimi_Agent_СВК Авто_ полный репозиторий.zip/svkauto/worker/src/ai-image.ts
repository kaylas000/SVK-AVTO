// worker/src/ai-image.ts
// Workers AI image generation

export async function generateImage(
  prompt: string,
  accountId: string,
  apiToken: string
): Promise<Uint8Array> {
  const fullPrompt = `${prompt}, automotive service, professional studio lighting, shallow depth of field, clean white or light grey background, premium quality, no text, no watermark, no labels, photorealistic`;

  const response = await fetch(
    `https://api.cloudflare.com/client/v4/accounts/${accountId}/ai/run/@cf/stabilityai/stable-diffusion-xl-base-1.0`,
    {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${apiToken}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        prompt: fullPrompt,
        width: 1200,
        height: 630
      })
    }
  );

  if (!response.ok) {
    throw new Error(`Image generation failed: ${response.status}`);
  }

  const data = await response.arrayBuffer();
  return new Uint8Array(data);
}
