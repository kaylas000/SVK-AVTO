// worker/src/geo.ts
// Geo filtering for chat

export interface GeoCheckResult {
  allowed: boolean;
  message?: string;
}

export function checkGeo(request: Request): GeoCheckResult {
  // Get CF properties from request
  const cf = (request as any).cf;
  
  if (!cf) {
    // Allow if no CF data (local testing)
    return { allowed: true };
  }

  const city = cf.city;
  const region = cf.region;
  const country = cf.country;

  // Allow Russia
  if (country !== 'RU') {
    return {
      allowed: false,
      message: 'Консультант работает для клиентов в России.'
    };
  }

  // Check if Moscow or Moscow region
  const isMoscow = 
    city === 'Moscow' || 
    region?.includes('Moscow') ||
    region?.includes('Москва');

  if (!isMoscow) {
    return {
      allowed: false,
      message: 'Мы специализируемся на обслуживании клиентов в Москве и Московской области. Если вы готовы приехать к нам — с удовольствием поможем!'
    };
  }

  return { allowed: true };
}
