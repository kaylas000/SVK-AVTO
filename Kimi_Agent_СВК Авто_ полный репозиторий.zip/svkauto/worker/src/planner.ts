// worker/src/planner.ts
// AI Blog Planner - generates editorial calendar

import { Env } from './index';

interface Topic {
  topic_id: string;
  category: string;
  system: string;
  angle: string;
  priority: number;
  cooldown_system_days: number;
  cooldown_system_angle_days: number;
  last_used_at: string | null;
  use_count: number;
}

interface GeneratedIdea {
  title_draft: string;
  keywords: string[];
  image_prompt: string;
}

// Generate content idea using Groq
async function generateIdea(topic: Topic, apiKey: string): Promise<GeneratedIdea> {
  const prompt = `Придумай заголовок и ключевые слова для статьи в блог автосервиса.

Тема: ${topic.category} — ${topic.system}
Угол: ${topic.angle}

Верни СТРОГИЙ JSON:
{
  "title_draft": "привлекательный заголовок статьи",
  "keywords": ["ключевое слово 1", "ключевое слово 2", "ключевое слово 3"],
  "image_prompt": "описание для генерации изображения, автомобильная тематика, профессиональное освещение, без текста"
}`;

  const response = await fetch('https://api.groq.com/openai/v1/chat/completions', {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${apiKey}`,
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({
      model: 'llama-3.1-8b-instant',
      messages: [
        { 
          role: 'system', 
          content: 'Ты — контент-менеджер автомобильного блога. Придумывай привлекательные заголовки. Отвечай только JSON.' 
        },
        { role: 'user', content: prompt }
      ],
      temperature: 0.8,
      max_tokens: 500
    })
  });

  if (!response.ok) {
    throw new Error(`Groq API error: ${response.status}`);
  }

  const data = await response.json();
  const content = data.choices[0]?.message?.content || '';
  
  const jsonMatch = content.match(/\{[\s\S]*\}/);
  if (!jsonMatch) {
    throw new Error('Failed to extract JSON from response');
  }

  return JSON.parse(jsonMatch[0]);
}

// Calculate simhash (simplified)
function calculateSimhash(text: string): string {
  // Simple hash for demonstration
  let hash = 0;
  for (let i = 0; i < text.length; i++) {
    const char = text.charCodeAt(i);
    hash = ((hash << 5) - hash) + char;
    hash = hash & hash;
  }
  return hash.toString(16);
}

// Calculate Hamming distance
function hammingDistance(hash1: string, hash2: string): number {
  let distance = 0;
  const maxLen = Math.max(hash1.length, hash2.length);
  const h1 = hash1.padStart(maxLen, '0');
  const h2 = hash2.padStart(maxLen, '0');
  
  for (let i = 0; i < maxLen; i++) {
    if (h1[i] !== h2[i]) distance++;
  }
  return distance;
}

// Check if topic passes cooldown rules
async function checkCooldown(
  db: D1Database, 
  topic: Topic, 
  plannedSlots: Array<{ category: string; system: string; pub_date: string }>
): Promise<boolean> {
  const now = new Date();
  
  // Check system cooldown
  if (topic.last_used_at) {
    const lastUsed = new Date(topic.last_used_at);
    const daysSince = (now.getTime() - lastUsed.getTime()) / (1000 * 60 * 60 * 24);
    if (daysSince < topic.cooldown_system_days) {
      return false;
    }
  }

  // Check category sequence (no same category in a row)
  if (plannedSlots.length > 0) {
    const lastSlot = plannedSlots[plannedSlots.length - 1];
    if (lastSlot.category === topic.category) {
      return false;
    }
  }

  // Check system in same week
  const recentSystemSlots = plannedSlots.filter(s => {
    const slotDate = new Date(s.pub_date);
    const daysDiff = Math.abs(now.getTime() - slotDate.getTime()) / (1000 * 60 * 60 * 24);
    return daysDiff <= 7 && s.system === topic.system;
  });
  if (recentSystemSlots.length > 0) {
    return false;
  }

  return true;
}

export async function handlePlanner(
  request: Request | null, 
  env: Env, 
  isManual: boolean
): Promise<Response> {
  // Auth check for manual trigger
  if (isManual && request) {
    const authHeader = request.headers.get('Authorization');
    if (!authHeader || !authHeader.startsWith('Bearer ') || 
        authHeader.slice(7) !== env.CHAT_AUTH_TOKEN) {
      return new Response('Unauthorized', { status: 401 });
    }
  }

  try {
    // Check how many planned slots we have
    const countResult = await env.DB.prepare(
      "SELECT COUNT(*) as count FROM calendar_slots WHERE status = 'planned'"
    ).first<{ count: number }>();

    const plannedCount = countResult?.count || 0;

    // If we have 14+ slots (2+ weeks), skip unless manual
    if (!isManual && plannedCount >= 14) {
      return new Response(JSON.stringify({ 
        message: 'Enough planned slots',
        plannedCount
      }), { headers: { 'Content-Type': 'application/json' } });
    }

    // Get existing planned slots for cooldown checks
    const plannedSlots = await env.DB.prepare(
      'SELECT category, system, pub_date FROM calendar_slots WHERE status = ? ORDER BY pub_date'
    )
    .bind('planned')
    .all<{ category: string; system: string; pub_date: string }>();

    const plannedSlotsList = plannedSlots.results || [];

    // Get available topics
    const topicsResult = await env.DB.prepare(
      'SELECT * FROM topics ORDER BY priority DESC, use_count ASC'
    ).all<Topic>();

    const topics = topicsResult.results || [];

    // Calculate next publishing dates (Mon, Wed, Fri)
    const moscowNow = new Date(new Date().getTime() + (3 * 60 * 60 * 1000));
    const publishingDates: string[] = [];
    
    let checkDate = new Date(moscowNow);
    while (publishingDates.length < 18) { // 6 weeks
      const dayOfWeek = checkDate.getDay();
      if ([1, 3, 5].includes(dayOfWeek)) { // Mon, Wed, Fri
        const dateStr = checkDate.toISOString().split('T')[0];
        // Check if slot already exists
        const existing = await env.DB.prepare(
          'SELECT 1 FROM calendar_slots WHERE pub_date = ?'
        ).bind(dateStr).first();
        
        if (!existing) {
          publishingDates.push(dateStr);
        }
      }
      checkDate.setDate(checkDate.getDate() + 1);
    }

    // Generate slots
    const generatedSlots: Array<{
      pub_date: string;
      topic_id: string;
      category: string;
      system: string;
      angle: string;
      title_draft: string;
      keywords: string;
      image_prompt: string;
      fingerprint: string;
    }> = [];

    for (const pubDate of publishingDates) {
      // Find suitable topic
      let selectedTopic: Topic | null = null;
      let idea: GeneratedIdea | null = null;

      for (const topic of topics) {
        // Skip if already used in this planning batch
        if (generatedSlots.some(s => s.topic_id === topic.topic_id)) {
          continue;
        }

        // Check cooldown
        const passesCooldown = await checkCooldown(env.DB, topic, [
          ...plannedSlotsList,
          ...generatedSlots.map(s => ({ category: s.category, system: s.system, pub_date: s.pub_date }))
        ]);

        if (!passesCooldown) {
          continue;
        }

        // Generate idea
        try {
          idea = await generateIdea(topic, env.GROQ_API_KEY);
          selectedTopic = topic;
          break;
        } catch (error) {
          console.error(`Failed to generate idea for topic ${topic.topic_id}:`, error);
          continue;
        }
      }

      if (!selectedTopic || !idea) {
        console.log(`No suitable topic found for ${pubDate}`);
        continue;
      }

      // Calculate fingerprint
      const fingerprint = calculateSimhash(
        `${idea.title_draft} ${idea.keywords.join(' ')}`
      );

      generatedSlots.push({
        pub_date: pubDate,
        topic_id: selectedTopic.topic_id,
        category: selectedTopic.category,
        system: selectedTopic.system,
        angle: selectedTopic.angle,
        title_draft: idea.title_draft,
        keywords: JSON.stringify(idea.keywords),
        image_prompt: idea.image_prompt,
        fingerprint
      });

      // Update topic use count
      await env.DB.prepare(
        'UPDATE topics SET use_count = use_count + 1, last_used_at = datetime("now") WHERE topic_id = ?'
      )
      .bind(selectedTopic.topic_id)
      .run();
    }

    // Insert slots
    for (const slot of generatedSlots) {
      await env.DB.prepare(`
        INSERT INTO calendar_slots 
        (pub_date, topic_id, category, system, angle, title_draft, keywords, image_prompt, fingerprint, status, created_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'planned', datetime('now'))
      `)
      .bind(
        slot.pub_date,
        slot.topic_id,
        slot.category,
        slot.system,
        slot.angle,
        slot.title_draft,
        slot.keywords,
        slot.image_prompt,
        slot.fingerprint
      )
      .run();
    }

    return new Response(JSON.stringify({ 
      success: true,
      message: 'Calendar planned',
      generatedSlots: generatedSlots.length,
      slots: generatedSlots.map(s => ({ date: s.pub_date, title: s.title_draft }))
    }), { headers: { 'Content-Type': 'application/json' } });

  } catch (error) {
    console.error('Planner error:', error);
    return new Response(JSON.stringify({ 
      error: 'Planning failed',
      message: error instanceof Error ? error.message : 'Unknown error'
    }), { 
      status: 500,
      headers: { 'Content-Type': 'application/json' }
    });
  }
}
