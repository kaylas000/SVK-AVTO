// worker/src/chat.ts
// AI Online Consultant handler

import { Env } from './index';
import { verifyTurnstile } from './turnstile';
import { checkQuota, incrementQuota } from './quota';
import { checkGeo } from './geo';

interface ChatMessage {
  role: 'user' | 'assistant';
  content: string;
}

interface ChatRequest {
  message: string;
  turnstile_token: string;
  history?: ChatMessage[];
}

// System prompt for all intents
const SYSTEM_PROMPT = `Ты — онлайн-консультант автосервиса СВК Авто.
Отвечай кратко, по-русски, дружелюбно и профессионально.
Никогда не придумывай цены, адреса, сроки, гарантии.
Если не уверен — предлагай позвонить по номеру +7 (495) 722‑36‑27 или +7 (495) 722‑36‑15.
Никогда не давай советы по самостоятельному ремонту узлов безопасности (тормоза, рулевое, ходовая).
Не называй конкурентов.

КЛЮЧЕВЫЕ ФАКТЫ:
- ТО за 5 000 ₽ (до 4,5 л масла), 7 000 ₽ (более 4,5 л)
- Диагностика ходовой: 680 ₽
- Диагностика тормозной: 680 ₽
- Компьютерная диагностика: 1 020 ₽
- Заправка кондиционера: 1 900 ₽
- Гарантия на работы до 6 месяцев
- Режим: ежедневно 09:00–20:00
- Адреса: ул. Поклонная, д. 11 (м. Парк Победы) и Кутузовский пр-т, д. 88`;

// Intent detection keywords
const INTENT_KEYWORDS: Record<string, string[]> = {
  booking: ['запись', 'записаться', 'приехать', 'метро', 'адрес', 'как добраться', 'телефон', 'часы работы'],
  to: ['то', 'техобслуживание', 'масло', 'фильтр', 'регламент', 'через сколько менять'],
  symptoms: ['стучит', 'скрипит', 'горит лампа', 'ошибка', 'не заводится', 'вибрация', 'тянет'],
  prices: ['сколько стоит', 'цена', 'прайс', 'дорого'],
  guarantee: ['гарантия', 'что если', 'возврат', 'претензия', 'условия', 'хранение']
};

// Detect intent from message
function detectIntent(message: string): string | null {
  const lowerMessage = message.toLowerCase();
  
  for (const [intent, keywords] of Object.entries(INTENT_KEYWORDS)) {
    for (const keyword of keywords) {
      if (lowerMessage.includes(keyword)) {
        return intent;
      }
    }
  }
  
  return null;
}

// Get response template for intent
function getIntentResponse(intent: string, env: Env): string {
  switch (intent) {
    case 'booking':
      return `Мы работаем ежедневно с 09:00 до 20:00.

**Станция «Поклонная»:**
📍 ул. Поклонная, д. 11, стр. 1 (м. Парк Победы)
📞 ${env.SITE_BASE_URL ? '+7 (495) 722‑36‑27' : '+7 (495) 722‑36‑27'}

**Станция «Кутузовский»:**
📍 Кутузовский пр-т, д. 88
📞 +7 (495) 722‑36‑15

Хотите записаться? Позвоните или оставьте заявку на сайте.`;

    case 'to':
      return `**Плановое ТО за 5 000 ₽** (до 4,5 л масла)

Что входит:
✓ Моторное масло и масляный фильтр
✓ Замена фильтров по регламенту
✓ Проверка жидкостей
✓ Диагностика ходовой и тормозной
✓ Считывание кодов OBD2
✓ Проверка давления в шинах
✓ Мойка в подарок

Для двигателей более 4,5 л — 7 000 ₽.

Записаться: +7 (495) 722‑36‑27`;

    case 'symptoms':
      return `Для точной диагностики необходим осмотр специалистом.

**Комплексная диагностика — 1 500 ₽** (мойка в подарок):
- Ходовая часть
- Тормозная система
- Компьютерная диагностика
- Проверка жидкостей

Запишитесь на диагностику: +7 (495) 722‑36‑27`;

    case 'prices':
      return `**Основные цены:**

- ТО (до 4,5 л): 5 000 ₽ (масло + фильтр)
- Диагностика ходовой: 680 ₽
- Диагностика тормозной: 680 ₽
- Компьютерная диагностика: 1 020 ₽
- Заправка кондиционера: 1 900 ₽
- Химчистка салона: от 7 000 ₽

Точная стоимость определяется после диагностики.

Полный прайс: ${env.SITE_BASE_URL || 'https://svkautoplus.ru'}/prices/`;

    case 'guarantee':
      return `**Гарантия на работы:**

- Диагностика: 14 дней
- Расходники: 14 дней
- Ремонт кондиционера: 3 месяца
- Ходовая/узлы: 6 месяцев
- Кузовные работы: 6 месяцев

Гарантия не распространяется на электрооборудование и детали клиента.

Подробнее: ${env.SITE_BASE_URL || 'https://svkautoplus.ru'}/guarantee/`;

    default:
      return null;
  }
}

// Call Groq API for fallback response
async function callGroq(message: string, history: ChatMessage[], apiKey: string): Promise<string> {
  const response = await fetch('https://api.groq.com/openai/v1/chat/completions', {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${apiKey}`,
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({
      model: 'llama-3.1-8b-instant',
      messages: [
        { role: 'system', content: SYSTEM_PROMPT },
        ...history.slice(-3),
        { role: 'user', content: message }
      ],
      temperature: 0.7,
      max_tokens: 500
    })
  });

  if (!response.ok) {
    throw new Error(`Groq API error: ${response.status}`);
  }

  const data = await response.json();
  return data.choices[0]?.message?.content || 'Извините, не удалось обработать запрос.';
}

export async function handleChat(request: Request, env: Env): Promise<Response> {
  // Only POST allowed
  if (request.method !== 'POST') {
    return new Response('Method Not Allowed', { status: 405 });
  }

  // Check Origin
  const origin = request.headers.get('Origin');
  if (origin && !origin.includes('svkautoplus.ru')) {
    return new Response('Forbidden', { status: 403 });
  }

  // Parse request
  let body: ChatRequest;
  try {
    body = await request.json();
  } catch {
    return new Response('Invalid JSON', { status: 400 });
  }

  const { message, turnstile_token, history = [] } = body;

  if (!message || !turnstile_token) {
    return new Response(JSON.stringify({ 
      error: 'Missing message or turnstile_token' 
    }), { 
      status: 400,
      headers: { 'Content-Type': 'application/json' }
    });
  }

  // Verify Turnstile
  const turnstileValid = await verifyTurnstile(turnstile_token, env.TURNSTILE_SECRET_KEY);
  if (!turnstileValid) {
    return new Response(JSON.stringify({ 
      error: 'Invalid Turnstile token' 
    }), { 
      status: 403,
      headers: { 'Content-Type': 'application/json' }
    });
  }

  // Check geo (soft filter)
  const geoCheck = checkGeo(request);
  if (!geoCheck.allowed) {
    return new Response(JSON.stringify({ 
      response: geoCheck.message,
      limit_reached: false
    }), {
      headers: { 'Content-Type': 'application/json' }
    });
  }

  // Get or create visitor ID from cookie
  const cookieHeader = request.headers.get('Cookie') || '';
  let visitorId = cookieHeader.match(/svk_visitor=([^;]+)/)?.[1];
  
  if (!visitorId) {
    visitorId = crypto.randomUUID();
  }

  // Check quota
  const quota = await checkQuota(env.DB, visitorId);
  if (quota >= 5) {
    return new Response(JSON.stringify({ 
      response: `Лимит вопросов исчерпан. Позвоните нам: +7 (495) 722‑36‑27 или оставьте заявку — перезвоним.`,
      limit_reached: true
    }), {
      headers: { 
        'Content-Type': 'application/json',
        'Set-Cookie': `svk_visitor=${visitorId}; HttpOnly; Secure; SameSite=Lax; Max-Age=86400`
      }
    });
  }

  // Detect intent and get response
  const intent = detectIntent(message);
  let response: string;

  if (intent) {
    const intentResponse = getIntentResponse(intent, env);
    if (intentResponse) {
      response = intentResponse;
    } else {
      response = await callGroq(message, history, env.GROQ_API_KEY);
    }
  } else {
    // Fallback to Groq for unknown intents
    response = await callGroq(message, history, env.GROQ_API_KEY);
  }

  // Increment quota
  await incrementQuota(env.DB, visitorId);

  return new Response(JSON.stringify({ 
    response,
    limit_reached: false
  }), {
    headers: { 
      'Content-Type': 'application/json',
      'Set-Cookie': `svk_visitor=${visitorId}; HttpOnly; Secure; SameSite=Lax; Max-Age=86400`
    }
  });
}
