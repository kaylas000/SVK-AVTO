// worker/src/indexnow.ts
// IndexNow submission

export async function submitToIndexNow(
  host: string,
  key: string,
  url: string
): Promise<void> {
  const response = await fetch('https://api.indexnow.org/indexnow', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({
      host: host.replace(/^https?:\/\//, ''),
      key,
      urlList: [url, `${host}/sitemap.xml`]
    })
  });

  if (!response.ok) {
    throw new Error(`IndexNow submission failed: ${response.status}`);
  }
}
